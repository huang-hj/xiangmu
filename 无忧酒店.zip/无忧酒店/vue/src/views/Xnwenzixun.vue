<template>
  <div class="home" data-spy="scroll">
   <div id="wrap_index"> <!-- 侧边导航 -->

<div class="class page-prev visible-xs visible-sm">
  <div class="close"></div>
  <div class="class-top">
    <form name="formsearch" action="/plus/search.php">
      <input type="hidden" name="kwtype" value="0">
      <input type="text" class="txt1" name="q" value="请输入关键字">
      <input type="submit" class="btn1" value="">
    </form>
  </div>
  <div class="class-m">
   <ul class="nnav">
            <li>
              <!-- <a href="../../../13097.html" class="ce">网站首页</a> -->
              <router-link to="/home" class="ce">网站首页</router-link>
            </li>
            <li class="menu_head">
              <router-link to="/guanyuwomen" class="ce">关于我们</router-link>
              <ul class="menu_body"></ul>
            </li>
            <li class="menu_head">
              <dl class="ericon">
                <span class="icon1"></span><span class="icon2"></span>
              </dl>
              <!-- <a href="../zhutilvyou/Index.html" class="ce">主题旅游</a> -->
              <router-link to="/zhutilvyou" class="ce">主题旅游</router-link>
              <ul class="menu_body">
                <li>
                  <router-link to="/zhutilvyou" class="er"
                    >国内游</router-link
                  >
                </li>

                <li>
                  <router-link to="/cjy1" class="er"
                    >出境游</router-link
                  >
                </li>
              </ul>
            </li>
            <li class="menu_head">
              <dl class="ericon">
                <span class="icon1"></span><span class="icon2"></span>
              </dl>
              <!-- <a href="../remenmudedi/Index.html" class="ce">热门目的地</a> -->
       <router-link to="/remenmudedi" class="ce">热门目的地</router-link>

              <ul class="menu_body">
                <li>
                  <router-link to="/yn" class="er">云南</router-link>
                </li>

                <li>
                  <router-link to="/sc" class="er"
                    >四川</router-link
                  >
                </li>

                <li>
                  <router-link to="/fj" class="er">福建</router-link>
                </li>
              </ul>
            </li>
            <li class="menu_head">
              <!-- <a href="../xinwenzixun/Index.html" class="ce">新闻资讯</a> -->
              <router-link to="/xnwenzixun" class="ce">新闻资讯</router-link>
              <ul class="menu_body"></ul>
            </li>
            <li class="menu_head">
              <dl class="ericon">
                <span class="icon1"></span><span class="icon2"></span>
              </dl>
              <!-- <a href="../shushijiudian/Index.html" class="ce">舒适酒店</a> -->
              <router-link to="/shushijiudian" class="ce">舒适酒店</router-link>

              <ul class="menu_body">
                <li>
                  <router-link to="/srj" class="er"
                    >双人间</router-link
                  >
                </li>

                <li>
                  <router-link to="/drj" class="er"
                    >单人间</router-link
                  >
                </li>

                <li>
                  <router-link
                    to="/zttf"
                    class="er"
                    >总统套房</router-link
                  >
                </li>
              </ul>
            </li>
            <li class="menu_head">
              <!-- <a href="../lianxiwomen/Index.html" class="ce">联系我们</a> -->
              <router-link to="/lianxiwomen" class="ce">联系我们</router-link>

              <ul class="menu_body"></ul>
            </li>
          </ul>
  </div>
</div>
<div class="opacity2"></div>
<div id="header" class="head visible-lg visible-md">
  <div class="container-fluid">
    <div class="logo wow fadeInLeft col-md-3"><router-link to="../home"><img src="../static/picture/logo.png"></router-link></div>
    <div class="col-md-9" style="height: 56px;">
      <div class="search col-md-3 wow fadeInRight" style="float: right;">
        <form name="formsearch" action="/plus/search.php">
          <input type="hidden" name="kwtype" value="0">
          <input class="txt1" type="text" name="q" placeholder="请输入关键字">
          <input class="btn1" type="submit" value="">
        </form>
      </div>
      <div class="col-md-9 nav wow fadeInDown navbar-nav nav_box" style="float: right; text-align: right;">
        <div class="yiji current"><router-link to="/home" >首页</router-link ></div>
        <div class="yiji"><router-link to="/guanyuwomen"><em>关于我们</em></router-link >
          <div style="display:none">
             </div>
        </div><div class="yiji"><router-link to="/zhutilvyou" ><em>主题旅游</em></router-link >
          <div class="libox">
             <router-link to="/zhutilvyou"><em>国内游</em></router-link>  <router-link to="/cjy1"><em>出境游</em></router-link>  </div>
        </div><div class="yiji"><router-link to="/remenmudedi"><em>热门目的地</em></router-link >
          <div class="libox">
             <router-link to="/yn"><em>云南</em></router-link>  <router-link to="/sc"><em>四川</em></router-link>  <router-link to="/fj"><em>福建</em></router-link>  </div>
        </div><div class="yiji"><router-link to="/xnwenzixun"><em>新闻资讯</em></router-link >
          <div style="display:none">
             </div>
        </div><div class="yiji"><router-link to="/shushijiudian"><em>舒适酒店</em></router-link >
          <div class="libox">
             <router-link to="/srj"><em>双人间</em></router-link>  <router-link to="/drj"><em>单人间</em></router-link>  <router-link to="/zt"><em>总统套房</em></router-link>  </div>
        </div><div class="yiji"><router-link to="/lianxiwomen"><em>联系我们</em></router-link >
          <div style="display:none">
             </div>
        </div> </div>
    </div>
  </div>
</div>
<div id="molheader" class="visible-sm visible-xs">
  <div class="logomol"><router-link to="/home"><img src="../static/picture/logo.png"></router-link></div>
  <div class="mol_navbutton"><img src="../static/picture/menu.png"></div>
</div>
 

      <!-- pcbanner -->
      <div id="myCarousel1" class="carousel slide visible-md visible-lg">
        <div class="carousel-inner">
          <div class="item active">
            <a><img src="../../../static/picture/b.jpg" /><em></em></a>
          </div>
        </div>
      </div>
      <!-- 手机banner -->
      <div id="molbanner" class="visible-xs visible-sm">
        <div class="swiper-container swiper-banner">
          <ul class="swiper-wrapper banner-img">
            <li class="swiper-slide">
              <a class="pic"><img src="../../../static/picture/b.jpg" /></a>
            </li>
          </ul>
        </div>
      </div>
      <div class="inner_main">
        <div class="ny_cont">
          <div class="nyttweizhi">
            <div class="nytitle agdollar wow fadeInLeft">
              <h2>新闻资讯</h2>
              <p>News information</p>
            </div>
            <div class="weizhi visible-md visible-lg">
              <router-link to="/home">主页</router-link> > <router-link to="/xnwenzixun">新闻资讯</router-link> >
            </div>
            <a href="javascript:;" class="classfiy visible-sm visible-xs"
              >分类 +</a
            >
          </div>
          <div class="navs">
            <ul class="mtree transit"></ul>
          </div>
          <div class="wrap_page aboutbgpage">
            <div class="page_content">
              <div class="nynav visible-md visible-lg">
                <ul class="clearfix"></ul>
              </div>
              <!-- 天气预报 -->
              <div id="tianqi">
                <h5>提前知晓未来七天的天气情况</h5>
                <div class="sousuo">
                  <input
                    v-model="city"
                    type="text"
                    class="input"
                    placeholder="请输出要查询的城市"
                  />
                  <img @click="search" src="../assets/放大镜.png" alt="" />
                </div>
                <p class="p" @click="di">
                  热门城市:<span>重庆</span><span>成都</span><span>上海</span>
                </p>
                <div class="xianshi">
                  <div class="wendu" v-for="(n, i) of wendu" :key="i">
                    <div>
                      <b>{{ n.type }}</b>
                      <b>{{ n.low }}~{{ n.high }}</b>
                      <b>{{ n.fengxiang }}</b>
                      <b>{{ n.date }}</b>
                    </div>
                  </div>
                  <p class="ganmao">{{ ganmao }}</p>
                </div>
              </div>

              <div class="ny_content">
                <ul class="clearfix newspage">
                  <li
                    class="col-md-6 col-sm-6 col-xs-12"
                    v-for="(xingwen, index) of xingwen"
                    :key="index"
                  >
                    <router-link
                      :to="{ path: '/xw1', query: { id: xingwen.xid } }"
                    >
                      <h2>{{ xingwen.theme }}</h2>
                      <p>{{ xingwen.detalis_1 }}</p>
                      <span>{{ xingwen.dates }}</span>
                    </router-link>
                  </li>
                </ul>
              </div>
              <div class="page visible-md visible-lg">
                <span class="pageinfo"
                  >共 <strong>1</strong>页<strong>6</strong>条记录</span
                >
              </div>
            </div>
            <div class="fixedfloat visible-md visible-lg">News information</div>
          </div>
        </div>
      </div>
      <div class="footbg clearfix">
        <div class="footwrap col-md-11">
          <div class="logofriendly clearfix">
            <div
              class="footlogo col-sm-12 col-xs-12 col-md-2 block"
              data-move-x="-100px"
              style="opacity: 0; transform: translateX(-100px)"
            >
              <img src="../../../static/picture/logo.png" />
            </div>
            <div
              class="footnav col-sm-12 col-xs-12 col-md-8 block"
              data-move-x="-100px"
              style="opacity: 0; transform: translateX(-100px)"
            >
              友情链接：
            </div>
          </div>
          <div class="copyright clearfix">
            <p class="p1">Copyright &copy; 2020 某某旅游有限公司 版权所有</p>
            <!--<p class="p2">技术支持：<a href="http://www.dede58.cn/"> 58</a></p>-->
          </div>
        </div>
        <div class="winxin col-md-1 visible-lg visible-md">
          <i><img src="../../../static/picture/weixin.png" /></i>
          <h2></h2>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      xingwen: [],
      city: "",
      wendu: "",
      ganmao: "",
    };
  },
  mounted() {
    this.axios.get("/xinwen").then((reslult) => {
      // console.log(reslult.data.data)
      this.xingwen = reslult.data.data;
      console.log(this.xingwen);
    });
  },
  methods: {
    di(e) {
      console.log(e.target.nodeName);
      if (e.target.nodeName == "SPAN") {
        this.city = e.target.innerText;
        this.search();
      }
    },
    search() {
      this.axios
        .get("http://wthrcdn.etouch.cn/weather_mini?city=" + this.city)
        .then((res) => {
          this.ganmao = res.data.data.ganmao;
          this.wendu = res.data.data.forecast;
          this.wendu.forEach((item) => {
            item.high = item.high.split(" ")[1];
            item.low = item.low.split(" ")[1];
          });
        });
    },
  },
};
</script>


  
<style scoped>
@import "../static/css/animate.css";
@import "../static/css/style.css";
@import "../static/css/swiper-3.3.1.min.css";
@import "../static/css/bootstrap.min.css";
</style>
<style scoped>
.ny_content a {
  text-decoration: none;
}
#tianqi > h5 {
  font-weight: bold;
  font-size: 18px !important;
  color: dodgerblue;
}
#tianqi .sousuo input {
  width: 80%;
  height: 34px;
  border: 1px solid dodgerblue;
  outline-style: none;
  border-right: none;
}
#tianqi .sousuo img {
  height: 34px;
  border: 1px solid dodgerblue;
  margin-top: -2px;
}
#tianqi .p {
  text-align: left;
  margin-left: 20px;
}
#tianqi .p > span {
  margin-left: 8px;
  color: brown;
}
#tianqi .xianshi {
  width: 100%;
  height: 200px;
  background-image: url("../assets/src=http___x0.ifengimg.com_res_2020_A3F8926542000E6D442B54AC05E67BC7A5A3AB5A_size88_w1023_h685.jpeg&refer=http___x0.ifengimg.jpg");
}
#tianqi .xianshi {
  border-right: 1px solid black;
}

#tianqi .xianshi b {
  display: block;
}
#tianqi .xianshi .wendu {
  display: inline-flex;
}
#tianqi .xianshi .wendu > div {
  margin-top: 20px;
}
#tianqi .xianshi .ganmao{
  color: brown;
  font-size: 18px;
  font-weight: bold;
  margin-top:15px ;
}
</style>