<template>
  <div class="home" data-spy="scroll">
   <div id="wrap_index"> <!-- 侧边导航 -->

<div class="class page-prev visible-xs visible-sm">
  <div class="close"></div>
  <div class="class-top">
    <form name="formsearch" action="/plus/search.php">
      <input type="hidden" name="kwtype" value="0">
      <input type="text" class="txt1" name="q" value="请输入关键字">
      <input type="submit" class="btn1" value="">
    </form>
  </div>
  <div class="class-m">
   <ul class="nnav">
            <li>
              <!-- <a href="../../../13097.html" class="ce">网站首页</a> -->
              <router-link to="/home" class="ce">网站首页</router-link>
            </li>
            <li class="menu_head">
              <router-link to="/guanyuwomen" class="ce">关于我们</router-link>
              <ul class="menu_body"></ul>
            </li>
            <li class="menu_head">
              <dl class="ericon">
                <span class="icon1"></span><span class="icon2"></span>
              </dl>
              <!-- <a href="../zhutilvyou/Index.html" class="ce">主题旅游</a> -->
              <router-link to="/zhutilvyou" class="ce">主题旅游</router-link>
              <ul class="menu_body">
                <li>
                  <router-link to="/zhutilvyou" class="er"
                    >国内游</router-link
                  >
                </li>

                <li>
                  <router-link to="/cjy1" class="er"
                    >出境游</router-link
                  >
                </li>
              </ul>
            </li>
            <li class="menu_head">
              <dl class="ericon">
                <span class="icon1"></span><span class="icon2"></span>
              </dl>
              <!-- <a href="../remenmudedi/Index.html" class="ce">热门目的地</a> -->
       <router-link to="/remenmudedi" class="ce">热门目的地</router-link>

              <ul class="menu_body">
                <li>
                  <router-link to="/yn" class="er">云南</router-link>
                </li>

                <li>
                  <router-link to="/sc" class="er"
                    >四川</router-link
                  >
                </li>

                <li>
                  <router-link to="/fj" class="er">福建</router-link>
                </li>
              </ul>
            </li>
            <li class="menu_head">
              <!-- <a href="../xinwenzixun/Index.html" class="ce">新闻资讯</a> -->
              <router-link to="/xnwenzixun" class="ce">新闻资讯</router-link>
              <ul class="menu_body"></ul>
            </li>
            <li class="menu_head">
              <dl class="ericon">
                <span class="icon1"></span><span class="icon2"></span>
              </dl>
              <!-- <a href="../shushijiudian/Index.html" class="ce">舒适酒店</a> -->
              <router-link to="/shushijiudian" class="ce">舒适酒店</router-link>

              <ul class="menu_body">
                <li>
                  <router-link to="/srj" class="er"
                    >双人间</router-link
                  >
                </li>

                <li>
                  <router-link to="/drj" class="er"
                    >单人间</router-link
                  >
                </li>

                <li>
                  <router-link
                    to="/zttf"
                    class="er"
                    >总统套房</router-link
                  >
                </li>
              </ul>
            </li>
            <li class="menu_head">
              <!-- <a href="../lianxiwomen/Index.html" class="ce">联系我们</a> -->
              <router-link to="/lianxiwomen" class="ce">联系我们</router-link>

              <ul class="menu_body"></ul>
            </li>
          </ul>
  </div>
</div>
<div class="opacity2"></div>
<div id="header" class="head visible-lg visible-md">
  <div class="container-fluid">
    <div class="logo wow fadeInLeft col-md-3"><router-link to="../home"><img src="../../../../static/picture/logo.png"></router-link></div>
    <div class="col-md-9" style="height: 56px;">
      <div class="search col-md-3 wow fadeInRight" style="float: right;">
        <form name="formsearch" action="/plus/search.php">
          <input type="hidden" name="kwtype" value="0">
          <input class="txt1" type="text" name="q" placeholder="请输入关键字">
          <input class="btn1" type="submit" value="">
        </form>
      </div>
      <div class="col-md-9 nav wow fadeInDown navbar-nav nav_box" style="float: right; text-align: right;">
        <div class="yiji current"><router-link to="/home" >首页</router-link ></div>
        <div class="yiji"><router-link to="/guanyuwomen"><em>关于我们</em></router-link >
          <div style="display:none">
             </div>
        </div><div class="yiji"><router-link to="/zhutilvyou" ><em>主题旅游</em></router-link >
          <div class="libox">
             <router-link to="/zhutilvyou"><em>国内游</em></router-link>  <router-link to="/cjy1"><em>出境游</em></router-link>  </div>
        </div><div class="yiji"><router-link to="/remenmudedi"><em>热门目的地</em></router-link >
          <div class="libox">
             <router-link to="/yn"><em>云南</em></router-link>  <router-link to="/sc"><em>四川</em></router-link>  <router-link to="/fj"><em>福建</em></router-link>  </div>
        </div><div class="yiji"><router-link to="/xnwenzixun"><em>新闻资讯</em></router-link >
          <div style="display:none">
             </div>
        </div><div class="yiji"><router-link to="/shushijiudian"><em>舒适酒店</em></router-link >
          <div class="libox">
             <router-link to="/srj"><em>双人间</em></router-link>  <router-link to="/drj"><em>单人间</em></router-link>  <router-link to="/zt"><em>总统套房</em></router-link>  </div>
        </div><div class="yiji"><router-link to="/lianxiwomen"><em>联系我们</em></router-link >
          <div style="display:none">
             </div>
        </div> </div>
    </div>
  </div>
</div>
<div id="molheader" class="visible-sm visible-xs">
  <div class="logomol"><router-link to="/home"><img src="../../../../static/picture/logo.png"></router-link></div>
  <div class="mol_navbutton"><img src="../../../../static/picture/menu.png"></div>
</div>
 
  <!-- pcbanner -->
  <div id="myCarousel1" class="carousel slide visible-md visible-lg">
    <div class="carousel-inner">
      <div class="item active"> <a><img src="../../../static/picture/b.jpg"><em></em></a> </div>
    </div>
  </div>
  <!-- 手机banner -->
  <div id="molbanner" class="visible-xs visible-sm">
    <div class="swiper-container swiper-banner">
      <ul class="swiper-wrapper banner-img">
        <li class="swiper-slide"><a class="pic"><img src="../../../static/picture/b.jpg"></a></li>
      </ul>
    </div>
  </div>
  <div class="wrap_page wrap_page1">
    <div class="page_content page_content1">
      <div class="newdtedit">
        <h2 class="tt">普吉岛旅行不可不做的几件事！</h2>
        <p class="time">2019-01-07 14:37</p>
        <p><p>
	如果你喜欢光着脚丫走在那软软的沙滩上，看那潮起潮落的海水，那普吉岛绝对是个绝佳的选择。喜欢热闹可以去芭东海滩，它是普吉岛人气最旺的海滩，让人感觉普吉岛上所有的游客都挤在了这。想清静一点，可以选卡塔或者卡隆海滩，既安静又不缺游玩设施。喜欢海滩的落日景观，那就去普吉岛最南端的神仙半岛，这里是赏普吉岛日落景色的最佳位置。</p>
<p>
	&nbsp;</p>
<p>
	【芭东海滩】大部分来到普吉岛的人都会住在芭东海滩这里。芭东海滩属于岛上比较繁华、设施完善的地方了。吃、住都比较方便，聚集了很多的酒店、饭店，而且价格不算贵。有一条很繁华的商业街，尤其到了晚上，非常繁华、热闹，还可以去看人妖表演。海边有很多可玩的娱乐项目，比如水上拖伞、橡皮艇、帆船、冲浪、摩托艇等。海水没有那么棒，但是在海滩边晒日光浴的歪果仁不少，很有度假氛围。</p>
<p>
	&nbsp;</p>
<p>
	【卡伦海滩】卡伦海滩是普吉岛第三大海滩之一。相比于芭东的繁华喧嚣，卡伦更加优雅宁静。那里的海滩污染较少，白白的沙滩蓝蓝的海水，适合租一个太阳伞沙滩椅，在沙滩上趟一下午。这里浪比较大，适合冲浪等水上运动。傍晚适合沙滩漫步，等待落日十分的黄昏美景，也不那么晒。卡伦海滩挨着芭东海滩，自己骑摩托车估计10min就到了。在卡伦海滩有很多的餐厅、酒吧。可以满足游客们的生活需要，提供各种当地美食和新鲜海鲜。此外，那里还有一个艺术社区，如果你喜欢艺术的话，可以到这里参观很多泰国画家建造的画室和画廊。我个人最喜欢的是view point，这是普吉岛上唯一一处可以同时看到三大海滩的观景台。简直太美了。</p>
<p>
	&nbsp;</p>
<p>
	【卡塔海滩】卡塔海滩很美，沙子很细，很安静。国人很少，因为他们基本上都在芭东。大早上你会看到很多老外在沙滩晨跑，还有一些美丽的异国姑娘在裸晒（哈哈，这是不是男士们的福利啊！）卡塔的海浪挺大，很多人在这里冲浪。我喜欢卡塔胜过芭东，因为这里不管有多少人都是静悄悄的，大家都在安静的享受自己的假日。&nbsp;</p>

      </div>
      <div class="other clearfix"> <a>上一篇：没有了 </a><a href='15.html'>下一篇：xx十大必游景点</a>  <a href="javascript:history.go(-1)" class="return visible-md visible-lg">返回</a> </div>
    </div>
  </div>
</div>

<div class="footbg clearfix">
  <div class="footwrap col-md-11">
    <div class="logofriendly clearfix">
      <div class="footlogo col-sm-12 col-xs-12 col-md-2 block" data-move-x="-100px" style="opacity: 0; transform: translateX(-100px);"><img src="../../../static/picture/logo.png"></div>
      <div class="footnav col-sm-12 col-xs-12 col-md-8 block" data-move-x="-100px" style="opacity: 0; transform: translateX(-100px);">友情链接：        </div>
    </div>
    <div class="copyright clearfix">
      <p class="p1">Copyright &copy; 2020 某某旅游有限公司 版权所有
        </p>
      <!--<p class="p2">技术支持：<a href="http://www.dede58.cn/"> 58</a></p>--> 
    </div>
  </div>
  <div class="winxin col-md-1 visible-lg visible-md"> <i><img src="../../../static/picture/weixin.png"></i>
    <h2></h2>
  </div>
</div>

  </div>
</template>








<script>

export default {
  data(){
    return{
      
    }
  },
 
  
}
</script>
  
<style scoped>
@import "../../../static/css/animate.css";
@import "../../../static/css/style.css";
@import "../../../static/css/swiper-3.3.1.min.css";
@import "../../../static/css/bootstrap.min.css";

</style>