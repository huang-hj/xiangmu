<template>
  <div class="home" data-spy="scroll">
   <div id="wrap_index"> <!-- 侧边导航 -->

<div class="class page-prev visible-xs visible-sm">
  <div class="close"></div>
  <div class="class-top">
    <form name="formsearch" action="/plus/search.php">
      <input type="hidden" name="kwtype" value="0">
      <input type="text" class="txt1" name="q" value="请输入关键字">
      <input type="submit" class="btn1" value="">
    </form>
  </div>
  <div class="class-m">
   <ul class="nnav">
            <li>
              <!-- <a href="../../../13097.html" class="ce">网站首页</a> -->
              <router-link to="/home" class="ce">网站首页</router-link>
            </li>
            <li class="menu_head">
              <router-link to="/guanyuwomen" class="ce">关于我们</router-link>
              <ul class="menu_body"></ul>
            </li>
            <li class="menu_head">
              <dl class="ericon">
                <span class="icon1"></span><span class="icon2"></span>
              </dl>
              <!-- <a href="../zhutilvyou/Index.html" class="ce">主题旅游</a> -->
              <router-link to="/zhutilvyou" class="ce">主题旅游</router-link>
              <ul class="menu_body">
                <li>
                  <router-link to="/zhutilvyou" class="er"
                    >国内游</router-link
                  >
                </li>

                <li>
                  <router-link to="/cjy1" class="er"
                    >出境游</router-link
                  >
                </li>
              </ul>
            </li>
            <li class="menu_head">
              <dl class="ericon">
                <span class="icon1"></span><span class="icon2"></span>
              </dl>
              <!-- <a href="../remenmudedi/Index.html" class="ce">热门目的地</a> -->
       <router-link to="/remenmudedi" class="ce">热门目的地</router-link>

              <ul class="menu_body">
                <li>
                  <router-link to="/yn" class="er">云南</router-link>
                </li>

                <li>
                  <router-link to="/sc" class="er"
                    >四川</router-link
                  >
                </li>

                <li>
                  <router-link to="/fj" class="er">福建</router-link>
                </li>
              </ul>
            </li>
            <li class="menu_head">
              <!-- <a href="../xinwenzixun/Index.html" class="ce">新闻资讯</a> -->
              <router-link to="/xnwenzixun" class="ce">新闻资讯</router-link>
              <ul class="menu_body"></ul>
            </li>
            <li class="menu_head">
              <dl class="ericon">
                <span class="icon1"></span><span class="icon2"></span>
              </dl>
              <!-- <a href="../shushijiudian/Index.html" class="ce">舒适酒店</a> -->
              <router-link to="/shushijiudian" class="ce">舒适酒店</router-link>

              <ul class="menu_body">
                <li>
                  <router-link to="/srj" class="er"
                    >双人间</router-link
                  >
                </li>

                <li>
                  <router-link to="/drj" class="er"
                    >单人间</router-link
                  >
                </li>

                <li>
                  <router-link
                    to="/zttf"
                    class="er"
                    >总统套房</router-link
                  >
                </li>
              </ul>
            </li>
            <li class="menu_head">
              <!-- <a href="../lianxiwomen/Index.html" class="ce">联系我们</a> -->
              <router-link to="/lianxiwomen" class="ce">联系我们</router-link>

              <ul class="menu_body"></ul>
            </li>
          </ul>
  </div>
</div>
<div class="opacity2"></div>
<div id="header" class="head visible-lg visible-md">
  <div class="container-fluid">
    <div class="logo wow fadeInLeft col-md-3"><router-link to="../home"><img src="../static/picture/logo.png"></router-link></div>
    <div class="col-md-9" style="height: 56px;">
      <div class="search col-md-3 wow fadeInRight" style="float: right;">
        <form name="formsearch" action="/plus/search.php">
          <input type="hidden" name="kwtype" value="0">
          <input class="txt1" type="text" name="q" placeholder="请输入关键字">
          <input class="btn1" type="submit" value="">
        </form>
      </div>
      <div class="col-md-9 nav wow fadeInDown navbar-nav nav_box" style="float: right; text-align: right;">
        <div class="yiji current"><router-link to="/home" >首页</router-link ></div>
        <div class="yiji"><router-link to="/guanyuwomen"><em>关于我们</em></router-link >
          <div style="display:none">
             </div>
        </div><div class="yiji"><router-link to="/zhutilvyou" ><em>主题旅游</em></router-link >
          <div class="libox">
             <router-link to="/zhutilvyou"><em>国内游</em></router-link>  <router-link to="/cjy1"><em>出境游</em></router-link>  </div>
        </div><div class="yiji"><router-link to="/remenmudedi"><em>热门目的地</em></router-link >
          <div class="libox">
             <router-link to="/yn"><em>云南</em></router-link>  <router-link to="/sc"><em>四川</em></router-link>  <router-link to="/fj"><em>福建</em></router-link>  </div>
        </div><div class="yiji"><router-link to="/xnwenzixun"><em>新闻资讯</em></router-link >
          <div style="display:none">
             </div>
        </div><div class="yiji"><router-link to="/shushijiudian"><em>舒适酒店</em></router-link >
          <div class="libox">
             <router-link to="/srj"><em>双人间</em></router-link>  <router-link to="/drj"><em>单人间</em></router-link>  <router-link to="/zt"><em>总统套房</em></router-link>  </div>
        </div><div class="yiji"><router-link to="/lianxiwomen"><em>联系我们</em></router-link >
          <div style="display:none">
             </div>
        </div> </div>
    </div>
  </div>
</div>
<div id="molheader" class="visible-sm visible-xs">
  <div class="logomol"><router-link to="/home"><img src="../static/picture/logo.png"></router-link></div>
  <div class="mol_navbutton"><img src="../static/picture/menu.png"></div>
</div>
 
  
  <!-- pcbanner -->
  <div id="myCarousel" class="carousel slide visible-md visible-lg"> 
     <!-- 轮播（Carousel）指标 -->
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <a class="carousel-control left" href="" data-slide="prev"> </a> <a class="carousel-control right" href="" data-slide="next"> </a>
    </ol>
    <!-- 轮播（Carousel）项目 -->
    <div class="carousel-inner"> <div class='item active'> <a><img src="../static/picture/1-1Z10G016130-L.jpg"><em></em></a> </div>
<div class='item'> <a><img src="../static/picture/1-1Z10G016130-L.jpg"><em></em></a> </div>
<div class='item'> <a><img src="../static/picture/1-1Z10G016130-L.jpg"><em></em></a> </div>
 </div>
  </div>
  <!-- 手机banner -->
  <div id="molbanner" class="visible-xs visible-sm">
    <div class="swiper-container swiper-banner">
      <ul class="swiper-wrapper banner-img">
        <li class="swiper-slide"><a class="pic"><img src="../static/picture/1-1Z10G016130-L.jpg"></a></li>
<li class="swiper-slide"><a class="pic"><img src="../static/picture/1-1Z10G016130-L.jpg"></a></li>
<li class="swiper-slide"><a class="pic"><img src="../static/picture/1-1Z10G016130-L.jpg"></a></li>

      </ul>
      <div class="pagination"></div>
      <div class="swiper-button-prev swiper-button-white"></div>
      <div class="swiper-button-next swiper-button-white"></div>
    </div>
  </div>
  <div class="section1">
    <ul class="clearfix">
      <li id="rm" class="li0 col-md-3 col-xs-6 block" data-move-x="-50px" style="opacity: 0; transform: translateX(-50px);"> 热门目的地<br>
        <em><strong></strong> DESTINATIONS</em> </li>
      <li class="li1 col-md-3 col-xs-6 block" data-rotate-y="180deg" data-move-z="-200px" data-move-x="-300px" style="opacity: 0; transform: translateX(-300px) translateZ(-200px) rotateY(180deg);"> <router-link to="/ls"><img src="../static/picture/1-1Z10G059480-L.jpg">
        <div class="mark">
          <div class="wrap_mark">
            <div class="wrap_mark1">
              <h2><i>乐山大佛</i> <em>Gulangyu</em></h2>
              <p class="visible-lg visible-md"></p>
            </div>
          </div>
        </div>
        </router-link> </li>
<li class="li1 col-md-3 col-xs-6 block" data-rotate-y="180deg" data-move-z="-200px" data-move-x="-300px" style="opacity: 0; transform: translateX(-300px) translateZ(-200px) rotateY(180deg);"> <router-link to="/jzg"><img src="../static/picture/1-1Z10G100110-L.jpg">
        <div class="mark">
          <div class="wrap_mark">
            <div class="wrap_mark1">
              <h2><i>九寨沟</i> <em>Jiuzhaigou</em></h2>
              <p class="visible-lg visible-md"></p>
            </div>
          </div>
        </div>
        </router-link> </li>
<li class="li1 col-md-3 col-xs-6 block" data-rotate-y="180deg" data-move-z="-200px" data-move-x="-300px" style="opacity: 0; transform: translateX(-300px) translateZ(-200px) rotateY(180deg);"> <router-link to="/hlg"><img src="../static/picture/1-1Z10G100350-L.jpg">
        <div class="mark">
          <div class="wrap_mark">
            <div class="wrap_mark1">
              <h2><i>海螺沟</i> <em>Hailuogou</em></h2>
              <p class="visible-lg visible-md"></p>
            </div>
          </div>
        </div>
        </router-link> </li>
<li class="li1 col-md-3 col-xs-6 block" data-rotate-y="180deg" data-move-z="-200px" data-move-x="-300px" style="opacity: 0; transform: translateX(-300px) translateZ(-200px) rotateY(180deg);"> <router-link to="/yl"><img src="../static/picture/1-1Z10G05G90-L.jpg">
        <div class="mark">
          <div class="wrap_mark">
            <div class="wrap_mark1">
              <h2><i>玉龙雪山</i> <em>Snow Mountain</em></h2>
              <p class="visible-lg visible-md"></p>
            </div>
          </div>
        </div>
        </router-link> </li>
<li class="li1 col-md-3 col-xs-6 block" data-rotate-y="180deg" data-move-z="-200px" data-move-x="-300px" style="opacity: 0; transform: translateX(-300px) translateZ(-200px) rotateY(180deg);"> <router-link to="/dl"><img src="../static/picture/1-1Z10G05Z60-L.jpg">
        <div class="mark">
          <div class="wrap_mark">
            <div class="wrap_mark1">
              <h2><i>大理古城</i> <em>Dali ancient city</em></h2>
              <p class="visible-lg visible-md"></p>
            </div>
          </div>
        </div>
        </router-link> </li>
<li class="li1 col-md-3 col-xs-6 block" data-rotate-y="180deg" data-move-z="-200px" data-move-x="-300px" style="opacity: 0; transform: translateX(-300px) translateZ(-200px) rotateY(180deg);"> <router-link to="eh"><img src="../static/picture/1-1Z10G05S70-L.jpg">
        <div class="mark">
          <div class="wrap_mark">
            <div class="wrap_mark1">
              <h2><i>洱海</i> <em>Erhai</em></h2>
              <p class="visible-lg visible-md"></p>
            </div>
          </div>
        </div>
        </router-link> </li>

      <li class="li2 col-md-3 col-xs-6 block" data-rotate-y="180deg" data-move-z="-200px" data-move-x="300px" style="opacity: 0; transform: translateX(300px) translateZ(-200px) rotateY(180deg);"> <router-link to="/remenmudedi">
        <div class="more">
          <h2>View more</h2>
          <em></em></div>
        </router-link> </li>
    </ul>
  </div>
  <div class="section2">
    <div class="wrap_section2">
      <h2 class="tt1 block" data-move-y="-50px" style="opacity: 0; transform: translateY(-100px);">关于我们</h2>
      <p class="tt2 block" data-move-y="-50px" style="opacity: 0; transform: translateY(-50px);">About Us <em></em></p>
      <p class="info block" data-move-x="-50px" style="opacity: 0; transform: translateX(-50px);">途牛旅游网创立于2006年10月，以让旅游更简单为使命，为消费者提供由北京、xx、广州、深圳等180个城市出发的旅游产品预订服务，产品全面，价格透明，全年365天24小时400电话预订，并提供丰富的后续服务和保障。 目前，途牛旅游网提供100万余种旅游产品供消费者选择，涵盖跟团、自助、自驾、邮轮、酒店、签证、景区门票以及公司旅游等，已成功服务累计超过1500万人次出游...</p>
      <router-link to="/guanyuwomen" class="more"></router-link>
      <div class="div_img"><img class="img" src="../static/picture/about.jpg"><em></em></div>
    </div>
  </div>
  <div class="section3">
    <div class="wrap_section3">
      <h2 class="tt1 textaligntt1 block" data-move-y="-100px" style="opacity: 0; transform: translateY(-100px);">主题旅游</h2>
      <p class="tt2 textaligntt2 block" data-move-y="-50px" style="opacity: 0; transform: translateY(-50px);">Theme tourism <em></em></p>
    </div>
    <ul>
      <li> <router-link to="/xgy"> <img class="img1 visible-lg visible-md" src="../static/picture/1-1Z10G201100-L.jpg"> <img class="img1 visible-xs visible-sm" src="../static/picture/1-1Z10G201100-L.jpg">
        <div class="mark">
          <div class="wrap_mark">
            <div class="wrap_mark1"> <img src="../static/picture/ic1.png">
              <p>Hong Kong</p>
              <em>香港2日半自助游</em> </div>
          </div>
        </div>
        <div class="mark1">
          <div class="wrap_mark">
            <div class="wrap_mark1"> <em>香港2日半自助游</em>
              <p>Hong Kong</p>
              <span class="more">查看更多</span> </div>
          </div>
        </div>
        </router-link> </li>
<li> <router-link to="/gly"> <img class="img1 visible-lg visible-md" src="../static/picture/1-1Z10G203290-L.jpg"> <img class="img1 visible-xs visible-sm" src="../static/picture/1-1Z10G203290-L.jpg">
        <div class="mark">
          <div class="wrap_mark">
            <div class="wrap_mark1"> <img src="../static/picture/ic1.png">
              <p>Gulangyu</p>
              <em>鼓浪屿</em> </div>
          </div>
        </div>
        <div class="mark1">
          <div class="wrap_mark">
            <div class="wrap_mark1"> <em>鼓浪屿</em>
              <p>Gulangyu</p>
              <span class="more">查看更多</span> </div>
          </div>
        </div>
        </router-link> </li>
<li> <router-link to="hly"> <img class="img1 visible-lg visible-md" src="../static/picture/1-1Z10G204390-L.jpg"> <img class="img1 visible-xs visible-sm" src="../static/picture/1-1Z10G204390-L.jpg">
        <div class="mark">
          <div class="wrap_mark">
            <div class="wrap_mark1"> <img src="../static/picture/ic1.png">
              <p>Huli mountain fort</p>
              <em>胡里山炮台</em> </div>
          </div>
        </div>
        <div class="mark1">
          <div class="wrap_mark">
            <div class="wrap_mark1"> <em>胡里山炮台</em>
              <p>Huli mountain fort</p>
              <span class="more">查看更多</span> </div>
          </div>
        </div>
        </router-link> </li>
<li> <router-link to="/fty"> <img class="img1 visible-lg visible-md" src="../static/picture/1-1Z10G205390-L.jpg"> <img class="img1 visible-xs visible-sm" src="../static/picture/1-1Z10G205390-L.jpg">
        <div class="mark">
          <div class="wrap_mark">
            <div class="wrap_mark1"> <img src="../static/picture/ic1.png">
              <p>Dream Kingdom</p>
              <em>方特梦幻王国</em> </div>
          </div>
        </div>
        <div class="mark1">
          <div class="wrap_mark">
            <div class="wrap_mark1"> <em>方特梦幻王国</em>
              <p>Dream Kingdom</p>
              <span class="more">查看更多</span> </div>
          </div>
        </div>
        </router-link> </li>

    </ul>
  </div>  
  <div class="section4">
    <div class="wrap_section4">
      <h2 class="tt1 textaligntt1 block" data-move-y="-100px" style="opacity: 0; transform: translateY(-100px);">新闻资讯</h2>
      <p class="tt2 textaligntt2 block" data-move-y="-50px" style="opacity: 0; transform: translateY(-50px);">News information <em></em></p>
      <div class="swiper-container news_swiper">
        <div class="swiper-wrapper"> <div class="swiper-slide"><router-link to="/xw6"><i><img style="width: 100%;" src="../static/picture/1-1Z10G440520-L.jpg"></i>
            <div class="info">
              <h2>在旅游过程中需要注意些什么</h2>
              <p>旅游出行前准备工作： 1、请在导游通知您后用手机存上导游的电话号码，以防在旅游过程当中有不方便的地方。 2、在您欣赏美景享受美食的同时，请保管...</p>
              <span>2019-01-07</span></div>
            </router-link></div>
<div class="swiper-slide"><router-link to="/xw5"><i><img style="width: 100%;" src="../static/picture/1-1Z10G440240-L.jpg"></i>
            <div class="info">
              <h2>又到圣诞，今年的圣诞都想好怎么过了吗</h2>
              <p>香港地区 第一站：尖沙咀 The One：轻松小熊陪你过圣诞 第二站：铜锣湾 皇室堡：轻松小熊波波池 时代广场：Snoopy Christmas 第三站：旺角 朗豪坊：Line你埋嚟...</p>
              <span>2019-01-07</span></div>
            </router-link></div>
<div class="swiper-slide"><router-link to="/xw4"><i><img style="width: 100%;" src="../static/picture/1-1Z10G439570-L.jpg"></i>
            <div class="info">
              <h2>泰国还有那么一座岛叫大长岛，那么的美</h2>
              <p>一直隐藏着的大长岛，很多人都没听过这个名字。但看过《机械师2》的朋友不知道会不会有印象，杰森斯坦森去找杨紫琼时，虽然官宣说是丽贝岛，但实际...</p>
              <span>2019-01-07</span></div>
            </router-link></div>
<div class="swiper-slide"><router-link to="/xw3"><i><img style="width: 100%;" src="../static/picture/1-1Z10G439190-L.jpg"></i>
            <div class="info">
              <h2>如果你只给纽约一天</h2>
              <p>纽约 这着实是一个让人无法轻易下定义的城市。 她有着物欲横流的大道，也有着宁静安逸的中央公园；她有着街头贩卖的艺术品，也有着绝世仅有的孤品...</p>
              <span>2019-01-07</span></div>
            </router-link></div>
<div class="swiper-slide"><router-link to="/xw2"><i><img style="width: 100%;" src="../static/picture/1-1Z10G43S40-L.jpg"></i>
            <div class="info">
              <h2>xx十大必游景点</h2>
              <p>作为中国最早接触外界的城市，xx一直是中国繁华都市的代表，素有魔都之称。根据蚂蜂窝用户出行数据，文中为大家呈现了xx最受欢迎的十大景点。...</p>
              <span>2019-01-07</span></div>
            </router-link></div>
<div class="swiper-slide"><router-link to="/xw1"><i><img style="width: 100%;" src="../static/picture/1-1Z10G43Q10-L.jpg"></i>
            <div class="info">
              <h2>普吉岛旅行不可不做的几件事！</h2>
              <p>如果你喜欢光着脚丫走在那软软的沙滩上，看那潮起潮落的海水，那普吉岛绝对是个绝佳的选择。喜欢热闹可以去芭东海滩，它是普吉岛人气最旺的海滩，...</p>
              <span>2019-01-07</span></div>
            </router-link></div>
 </div>
        <!-- Add Pagination -->
        <div class="swiper-pagination"></div>
      </div>
      <div class="swiper-button-next"></div>
      <div class="swiper-button-prev"></div>
    </div>
  </div>
  <div class="footbg clearfix">
  <div class="footwrap col-md-11">
    <div class="logofriendly clearfix">
      <div class="footlogo col-sm-12 col-xs-12 col-md-2 block" data-move-x="-100px" style="opacity: 0; transform: translateX(-100px);"><img src="../static/picture/logo.png"></div>
      <div class="footnav col-sm-12 col-xs-12 col-md-8 block" data-move-x="-100px" style="opacity: 0; transform: translateX(-100px);">友情链接：        </div>
    </div>
    <div class="copyright clearfix">
      <p class="p1">Copyright &copy; 2020 某某旅游有限公司 版权所有
        </p>
      <!--<p class="p2">技术支持：<a href="http://www.dede58.cn/"> 58</a></p>--> 
    </div>
  </div>
  <div class="winxin col-md-1 visible-lg visible-md"> <i><img src="../static/picture/weixin.png"></i>
    <h2></h2>
  </div>
</div>
 </div>
  </div>
</template>








<script>

export default {
  data(){
    return{}
  },
 
  
}
</script>
  
<style scoped>
@import "../static/css/animate.css";
@import "../static/css/style.css";
@import "../static/css/swiper-3.3.1.min.css";
@import "../static/css/bootstrap.min.css";
#rm{
  margin-top: 50px;
}
</style>