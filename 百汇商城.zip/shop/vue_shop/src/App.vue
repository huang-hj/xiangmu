<template>
  <div id="app">
    <HelloWorld msg="Welcome to Your Vue.js App" />
    <div class="container">
      <mt-header fixed :title="$route.meta.title">
        <span slot="left" @click="goBack" v-show="showBack">
          <mt-button icon="back">返回</mt-button>
        </span>
      </mt-header>

      <router-view></router-view>

      <tabbar></tabbar>

    </div>

  </div>
</template>


<script>
import HelloWorld from './components/HelloWorld.vue'
import tabbar from './components/tabbar.vue'

export default {
  data () {
    return {
      showBack: false
    }
  },
  created () {
    this.showBack = this.$route.path !== '/home'
    this.checkLogin()
  },
  watch: {
    '$route.path' (newVal) {
      this.showBack = newVal !== '/home'
    }
  },
  methods: {
    goBack () {
      this.$router.go(-1)
    },



  },


  name: 'App',
  components: {
    HelloWorld,
    tabbar
  }
}
</script>

<style lang="scss" scoped>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 40px;
}
</style>
