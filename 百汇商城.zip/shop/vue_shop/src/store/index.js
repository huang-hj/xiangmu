import Vue from "vue";
import Vuex from "vuex";
Vue.use(Vuex);

export default new Vuex.Store({
  state: {
    orderDetails: {},
    userInfo: JSON.parse(sessionStorage.getItem("usermaster")),
    isLogin: sessionStorage.getItem("usermaster") ? 1 : 0,
    shop_shop: JSON.parse(sessionStorage.getItem("usershop")),
    userapp: [],
  },

  mutations: {
    storage(state, orderDetails) {
      state.orderDetails = orderDetails;
    },
    updateAge(state, userInfo) {
      state.userInfo = userInfo;
      state.isLogin = 1;
      console.log(state.isLogin);
    },
    remove(state, num) {
      state.isLogin = num;
      console.log(state.isLogin);
    },
    upusershop(state, details_shop) {
      state.shop_shop = details_shop;
      state.userapp.push(state.shop_shop);
    },
  },
  actions: {},
  modules: {},
});
