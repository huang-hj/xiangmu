export default {
  baseURL: "http://tpadmin.test/api/",
};
