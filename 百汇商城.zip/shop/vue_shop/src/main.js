import Vue from "vue";
import App from "./App.vue";
import store from "./store";
import router from "./router.js";
import "./lib/mui/css/mui.css";
import "./lib/mui/css/icons-extra.css";

import less from "less";
Vue.use(less);

import qs from "qs";
import moment from "moment";
import VueResource from "vue-resource";
Vue.use(VueResource);

Vue.prototype.moment = moment;
Vue.prototype.qs = qs;
Vue.config.productionTip = false;
import auth from "./auth.js";
Vue.use(auth);

//引入axios模块
import axios from "axios";
axios.defaults.baseURL = "/api";
axios.defaults.baseURL = "http://127.0.0.1:8585/";
axios.defaults.baseURL = "http://localhost:8585/";

Vue.prototype.axios = axios;

Vue.config.productionTip = false;

import MintUI from "mint-ui";
import "mint-ui/lib/style.css";
Vue.use(MintUI);

new Vue({
  store,
  router,
  render: (h) => h(App),
}).$mount("#app");
