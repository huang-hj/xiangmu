<template>
  <mt-swipe :auto="4000">
    <mt-swipe-item v-for="item of swiperList" :key="item.id">
      <img :src="item.imgUrl">
    </mt-swipe-item>
  </mt-swipe>
</template>
<script>
export default {
  name:'Swiper',
    data(){
        return{
            swiperOptions:{
                pagination:'.swiper-pagination',
            },
            swiperList:[
                {
                    id:'0001',
                    imgUrl:require('../assets/images/1.jpg'),

            },
            {
                 id:'0002',
                 imgUrl:require('../assets/images/2.jpg'),

            },
            {
                 id:'0003',
                 imgUrl:require('../assets/images/3.jpg'),
            }
            ],
            
        }
    }
}
</script>
<style lang="scss" scoped>
.mint-swipe {
  height: 200px;
  color: #fff;
  .mint-swipe-items-wrap {
    .mint-swipe-item {
      text-align: center;
    }
  img {
      width: 100%;
      height: 100%;
    }
  }
}
</style>
