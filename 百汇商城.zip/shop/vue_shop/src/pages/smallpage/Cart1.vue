<template>
  <div>
    <div>
      <img class="i1"
        src="https://img.alicdn.com/imgextra/i1/2201454286190/O1CN01yUpJtK1vb4IFnHRxP_!!2201454286190.jpg_310x310.jpg"
        alt="">
      <h3>{{name}}</h3>
      <p>月售233</p>
      <h2>￥{{price}}</h2>
      <button @click="jian" class="btnjian">－</button>
      <span class="zs">{{cartCount}}</span>
      <button @click="jia" class="btnjia">＋</button>
      <button class="addCart" @click="addCart">加入购物车</button>
    </div>
  </div>
</template>
<style  scoped>
.zs {
  padding-top: 5px;
}
.btnjian,
.btnjia,
.zs {
  margin-top: 10px;
  margin-right: 10px;
  float: left;
}
.sl {
  width: 30px;
  height: 30px;
}
.i1 {
  width: 100%;
}
h3,
p {
  text-align: left;
}
h2 {
  text-align: left;
  color: red;
}
.addCart {
  background-color: dodgerblue;
  width: 100px;
  height: 40px;
  font-size: 15px;
  font-weight: bold;
  margin-top: 30px;
  float: right;
}
</style>>
  <script>

export default {
  data () {
    return {
      name: "小米k30",
      price: 2999,
      cartCount: '1',

    }
  },
  methods: {

    jia () {

      this.cartCount++
    },
    jian () {
      if (this.cartCount > 1)
        this.cartCount--;
    },
    addCart () {
      alert(`已经添加到购物车`)

    }

  }
}
</script>