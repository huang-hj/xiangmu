<template>
  <div class="tou">

    <mt-field class="b2" label="用户名:" type="text" placeholder="请输入用户名" v-model="username" :state="usernameState"
      disableClear></mt-field>
    <mt-field class="b2" label="密码:" type="password" v-model="password" :state="passwordState" placeholder="请输入密码">
    </mt-field>
    <!-- <mt-field
            type="password"
            placeholder="请输入验证码"
            class="d1"
            disableClear
          ></mt-field>
    </mt-cell>-->
    <div class="aw">
      <router-link to="/user/register" slot="right" class="shortcut">
        还没有账号？前往注册
      </router-link>
    </div>
    <mt-button type="primary" size="large" @click="handle">登录</mt-button>
  </div>
</template>

<script>
export default {
  data () {
    return {
      username: "",
      usernameState: "",
      password: "",
      passwordState: ""
    };
  },
  methods: {
    handle () {
      //处理点击确认注册事件
      let username = this.username;
      // 检验用户名
      let usernameReg = /^1[0-9]{10}$/;
      if (usernameReg.test(username)) {
        //符合正则表达式
        this.usernameState = "success";
      } else {
        //不符合正则表达式
        this.usernameState = "error";
        return false;
      }

      // 检验密码
      let password = this.password;
      // console.log(password)
      let passwordReg = /^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{6,16}$/;
      if (passwordReg.test(password)) {
        //符合正则表达式
        this.passwordState = "success";
      } else {
        //不符合正则表达式
        this.passwordState = "error";
        return false;
      }
      //发送请求
      let pooss = `email=${this.username}&upwd=${this.password}`;
      this.axios.post("/login", pooss).then(res => {
        console.log(res);
        if (res.data.code == 0) {
          //登录成功
          this.$router.push("/");
          sessionStorage.setItem(
            "usermaster",
            JSON.stringify(res.data.usermaster)
          );
          this.$store.commit("updateAge", res.data.usermaster);
        } else {
          this.$toast("登录失败:" + res.data.message);
        }
      });
    }
  }
};
</script>
<style scoped>
.tou > header {
  background-color: #c0191f;
  height: 45px;
  font-size: 18px;
}

.z {
  font-size: 16px;
  text-decoration: none;
}
.aw {
  text-align: right;
  margin-top: 20px;
}
.aw >>> a {
  color: #90704d;
  font-size: 16px;
  text-decoration: none;
}

.b2 >>> .mint-cell-wrapper {
  background-image: none;
}
.b2 >>> .mint-cell-title {
  width: 70px;
  text-align-last: justify;
  text-align: justify;
  color: rgb(136, 136, 136);
}
.b2 >>> .mint-cell-value {
  padding-left: 14px;
}
.b2 >>> input::-webkit-input-placeholder {
  color: #d3d0d0;
  font-size: 16px;
}
</style>