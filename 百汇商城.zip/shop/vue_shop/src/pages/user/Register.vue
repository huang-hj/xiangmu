<template>
  <div class="tou">

    <div>
      <mt-field label="手机号:" type="text" placeholder="请输入手机号码" class="b2" v-model="shouji" :state="shoujis"
        @blur.native.capture="checkShoujis" disableClear></mt-field>

      <mt-field label="密码:" type="password" placeholder="码密码至少包含 数字和英文，长度6-16" class="b2" v-model="password"
        :state="passwords" @blur.native.capture="checkPassword" disableClear></mt-field>
      <mt-field label="确认密码:" type="password" placeholder="请再次输入登录密码" class="b2" v-model="password2" :state="passwords2"
        disableClear></mt-field>
      <!-- <mt-field type="" placeholder="请输入验证码"  
          disableClear></mt-field> -->
      <div id="aw"></div>
      <mt-button type="primary" size="large" @click="handie" class="d">注册</mt-button>
    </div>
  </div>
</template>
<script>
export default {
  data () {
    return {
      shouji: "",
      shoujis: "",
      denglu: "",
      denglus: "",
      password: "",
      passwords: "",
      password2: "",
      passwords2: "",
    };
  },
  methods: {
    checkShoujis () {
      let shouji = this.shouji;
      // 检验用户名
      let shoujiReg = /^1[0-9]{10}$/;
      if (shoujiReg.test(shouji)) {
        //符合正则表达式
        this.shoujis = "success";
      } else {
        //不符合正则表达式
        this.shoujis = "error";
        return false;
      }
    },

    checkPassword () {
      let password = this.password;
      let passwordReg = /^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{6,16}$/;
      if (passwordReg.test(password)) {
        //符合正则表达式
        this.passwords = "success";
      } else {
        //不符合正则表达式
        this.passwords = "error";
        return false;
      }
      let password2 = this.password2;
      if (password == password2) {
        // 两密码相同
        this.passwords2 = "success";
      } else {
        // 两密码不同
        this.passwords2 = "error";
        return false;
      }
    },
    handie () {
      //处理点击确认注册事件
      let shouji = this.shouji;
      // 检验用户名
      let shoujiReg = /^1[0-9]{10}$/;
      if (shoujiReg.test(shouji)) {
        //符合正则表达式
        this.shoujis = "success";
      } else {
        //不符合正则表达式
        this.shoujis = "error";
        return false;
      }

      // 检验密码
      let password = this.password;
      let passwordReg = /^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{6,16}$/;
      if (passwordReg.test(password)) {
        //符合正则表达式
        this.passwords = "success";
      } else {
        //不符合正则表达式
        this.passwords = "error";
        return false;
      }

      //验证重复密码
      let password2 = this.password2;
      if (password == password2) {
        // 两密码相同
        this.passwords2 = "success";
      } else {
        // 两密码不同
        this.passwords2 = "error";
        return false;
      }
      //发送请求
      let pooss = `email=${this.shouji}&uname=${this.denglu}&upwd=${this.password}`
      this.axios.post(
        '/register', pooss).then((res) => {
          console.log(res)
          if (res.data.code == 0) {//注册成功
            this.$messagebox({
              title: '提示',
              message: '注册成功',
              confirmButtonText: '登录',
              cancelButtonText: '取消返回主页',
              showCancelButton: true
            }).then(ac => {
              if (ac == 'confirm') {
                this.$router.push('/login')
              } else {
                this.$router.push('/')
              }
            })
          } else {
            this.$toast('注册失败:' + res.data.message)
          }
        })
    },
  },
};
</script>