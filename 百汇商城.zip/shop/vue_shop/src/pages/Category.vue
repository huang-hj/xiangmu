<template>
  <div>
    <div class="menu">
      <div class="menu-left">
        <ul>
          <li class="menu-item">
            <p class="text"><a href="javascript:;" @click="curId=0" :class="{'cur':curId===0}">手机数码</a></p>
            <p class="text"><a href="javascript:;" @click="curId=1" :class="{'cur':curId===1}">家用电器</a></p>
            <p class="text"><a href="javascript:;" @click="curId=2" :class="{'cur':curId===2}">蔬菜瓜果</a></p>
            <p class="text"><a href="javascript:;" @click="curId=3" :class="{'cur':curId===3}">酒水饮料</a></p>
            <p class="text"><a href="javascript:;" @click="curId=4" :class="{'cur':curId===4}">电脑办公</a></p>
            <p class="text"><a href="javascript:;" @click="curId=5" :class="{'cur':curId===5}">动漫周边</a></p>
          </li>
        </ul>
      </div>
      <!-- 右 -->
      <div class="wrapper">
        <div class="content">

          <div v-show="curId===0">
            手机数码
            <div class="menu-right">
              <ul>
                <li class="cate">
                  <ul class="cate-item">
                    <li v-for="item in menu" :key="item.id" class="d1">
                      <h3 class="cate-item-wrapper">
                        <div class="cate-item-img">
                          <img :src="item.image" alt="" @click="xqy">
                        </div>
                      </h3>
                      <span>{{ item.name }}</span>

                    </li>
                  </ul>
                </li>
              </ul>
            </div>
          </div>
          <div v-show="curId===1">
            家用电器
            <div class="menu-right">
              <ul>
                <li class="cate">
                  <ul class="cate-item">
                    <li v-for="item in menu2" :key="item.id" class="d1">
                      <a href="item.herf" class="cate-item-wrapper">
                        <div class="cate-item-img">
                          <img :src="item.image" alt="">
                        </div>
                      </a>
                      <span>{{ item.name }}</span>

                    </li>
                  </ul>
                </li>
              </ul>
            </div>
          </div>
          <div v-show="curId===2">
            蔬菜瓜果
          </div>
          <div v-show="curId===3">
            酒水饮料
          </div>
          <div v-show="curId===4">
            电脑办公
          </div>
          <div v-show="curId===5">
            动漫周边
          </div>
        </div>
      </div>
    </div>

  </div>
</template>
<script src="https://unpkg.com/better-scroll/dist/bscroll.min.js"></script>

<script>
import BScroll from "better-scroll"

export default {
  data () {
    return {
      curId: 0,
      computed: {},



      menu: [
        {
          id: 1,
          name: "小米",
          image: "https://img.alicdn.com/imgextra/i1/2201454286190/O1CN01yUpJtK1vb4IFnHRxP_!!2201454286190.jpg_310x310.jpg"
        },
        {
          id: 2,
          name: "华为",
          image: "https://img.alicdn.com/imgextra/i2/2757470864/O1CN015aKomO1IFkrS7ymHE_!!2757470864.jpg_310x310.jpg"
        }, {
          id: 3,
          name: "vivo",
          image: "http://img.alicdn.com/imgextra/i3/2291624900/O1CN01n6YbS71m4FMGoNdYv_!!2291624900.jpg_310x310.jpg"
        }, {
          id: 4,
          name: "三星",
          image: "https://img.alicdn.com/imgextra/i4/12590764/O1CN01DAk3nb1HVxFyFRqM6_!!12590764.png_310x310.jpg"
        },
        {
          id: 5,
          name: "三星",
          image: "https://img.alicdn.com/imgextra/i4/12590764/O1CN01DAk3nb1HVxFyFRqM6_!!12590764.png_310x310.jpg"
        },
        {
          id: 6,
          name: "三星",
          image: "https://img.alicdn.com/imgextra/i4/12590764/O1CN01DAk3nb1HVxFyFRqM6_!!12590764.png_310x310.jpg"
        },
        {
          id: 7,
          name: "三星",
          image: "https://img.alicdn.com/imgextra/i4/12590764/O1CN01DAk3nb1HVxFyFRqM6_!!12590764.png_310x310.jpg"
        },
      ],
      menu2: [
        {
          id: 1,
          name: "苏泊尔",
          image: "https://img.alicdn.com/bao/uploaded/i1/2247381813/O1CN01wj0pu91PGOj6OvfXk_!!2247381813-0-picasso.jpg_310x310.jpg"
        },
        {
          id: 2,
          name: "九阳",
          image: "https://img.alicdn.com/bao/uploaded/i3/4238961372/O1CN01Y01r4V1M0Pvc0XkKB_!!4238961372.jpg_310x310.jpg"
        }, {
          id: 3,
          name: "麦饭石",
          image: "https://img.alicdn.com/bao/uploaded/i4/2200691991577/O1CN01rHbwwW1NWJB0bp4Nl_!!2200691991577.jpg_310x310.jpg"
        }, {
          id: 4,
          name: "非凡",
          image: "https://img.alicdn.com/bao/uploaded/i3/2208743005887/O1CN01L0s23W1tMIIBubpB0_!!0-item_pic.jpg_310x310.jpg"
        },
      ]

    };

  },
  mounted () {
    let scroll = new BScroll(".wrapper")
    console.log("scroll")
    function onScroll (pos) {
      console.log("scroll")
    }
    scroll.on("scroll", onscroll)
  },
  methods: {
    xqy () {
      this.$router.push('/smallpage/cart1')
    }
  },

};
</script>
<style lang="scss" scoped>
.d1 {
  margin-top: 10px;
  border: 1px solid rgb(11, 189, 180);
  border-radius: 3%;
}
ul {
  margin: 0;
  padding: 0;
}
li {
  list-style: none;
}
.menu {
  display: flex;
  position: absolute;
  text-align: center;
  top: 40px;
  bottom: 50px;
  width: 100%;
  overflow: hidden;
  .menu-left {
    flex: 0 0 80px;
    width: 80px;
    background: #f3f5f7;
    .menu-item {
      height: 54px;
      width: 100%;
      .text {
        width: 100%;
        line-height: 54px;
        margin-bottom: 0;
      }
    }
    .current {
      width: 100%;
      background: #fff;
      .text {
        color: red;
      }
    }
  }
  .menu-right {
    flex: 1;
    background: #fff;
    .cate {
      height: 100%;

      .cate-item {
        width: 100%;
        padding: 7px 10px 10px;
        display: flex;
        overflow: hidden;
        flex-flow: row wrap;

        li {
          width: 100%;
          .cate-item-wrapper {
            .cate-item-img {
              width: 100%;
              img {
                width: 50%;
                height: 50%;
              }
            }
          }
          span {
            margin: 0 auto;
            display: inline-block;
            font-size: 14px;
            color: #333;
          }
        }
      }
    }
  }
}
</style>
