//����expressģ��
const express = require("express");
//����������
const app = express();
//���ÿ���
const cors = require("cors");
app.use(cors({ origin: ["http://localhost:8080", "http://127.0.0.1:8080"] }));
//����mysqlģ��
const mysql = require("mysql");
//�������ӳ�
const pool = mysql.createPool({
  host: "127.0.0.1",
  port: "3306",
  user: "root",
  password: "",
  database: "hotel",
  connectionLimit: "20",
});
//���÷������˿�
app.listen(8585);

//引入body-parser
const bodyParser = require("body-parser");
app.use(bodyParser.urlencoded({ extended: false }));

//�����Ƶ�����·��
//app.get('/details',(req,res) => {
//	let sql = `select s.uid uid,s.names names,s.imgs imgs,s.details_id details_id,s.sites sites,s.paths paths,s.opening_time //opening_time,s.quality quality,d.title title,d.price price,d.imgs details_img,d.discount_price discount_price,d.area area,d.window //window,d.other other,d.size size,d.bed bed from hotel_shop s inner join hotel_details d on s.uid=d.shop_id where d.shop_id=?`
//	pool.query(sql,[req.query.uid],(err,result) => {
//		if(err) throw err;
//		if(result.length > 0){
//			res.send({'code':1,'message':'ok','data':result})
//		}else{
//			res.send({'code':0,'message':'No Data'})
//		}
//	})
//})
app.get("/details", (req, res) => {
  let sql = `select * from hotel_shop where uid=?`;
  pool.query(sql, [req.query.uid], (err, result) => {
    if (err) throw err;
    let sql2 = `select * from hotel_details where shop_id=?`;
    pool.query(sql2, [req.query.uid], (errs, results) => {
      if (errs) throw errs;
      if (result.length > 0) {
        res.send({ code: 1, message: "ok", data: result[0], details: results });
      } else {
        res.send({ code: 0, message: "No Data" });
      }
    });
  });
});
//������ѯ�Ƶ�����ͼƬ·��
app.get("/hotelinfo", (req, res) => {
  let sql = `select * from hotel_picture where shop_id=?`;
  pool.query(sql, [req.query.shop_id], (err, result) => {
    if (err) throw err;
    if (result.length > 0) {
      res.send({ code: 1, message: "ok", data: result });
    } else {
      res.send({ code: 0, message: "No Data" });
    }
  });
});

//谢疆
//接收请求，返回酒店列表详情
app.get("/text", (req, res) => {
  let page = req.query.page;
  if (!page) {
    //没page参数
    page = 1;
  }
  //通过cid 查询数据库  并且实现分页
  /** page     offset    pagesize
   *  1        0         10
   *  2        10        10
   *  3        20        10
   *  .....
   *  n        (n-1)*10  10
   */
  let pagesize = 6;
  let offset = (page - 1) * pagesize;
  let sql = "select * from hotel_shop limit ?,?";
  pool.query(sql, [offset, pagesize], (error, results) => {
    // console.log(results)
    if (error) throw error;
    if (results.length) {
      // 有数据
      res.send({ code: 0, message: "OK", data: results });
    } else {
      // 没有数据
      res.send({ code: 1, message: "No Data" });
    }
  });
});

//周黄平
//注册
app.post("/register", (req, res) => {
  let email = req.body.email;
  let uname = req.body.uname;
  let upwd = req.body.upwd;
  // 验证手机号是否存在
  let sql = "select * from hotel_user where email=?";
  pool.query(sql, [email], (error, results) => {
    if (error) throw error;
    if (results.length) {
      // 账户已存在
      res.send({ code: 1, message: "账户已存在" });
    } else {
      // 不存在插入数据
      let sql2 = "insert into hotel_user (email, uname,upwd) values (?,?,?)";
      pool.query(sql2, [email, uname, upwd], (error, results2) => {
        if (error) throw error;
        // console.log(results2)
        res.send({ code: 0, message: "OK" });
      });
    }
  });
});
//登录
app.post("/login", (req, res) => {
  let email = req.body.email;
  let upwd = req.body.upwd;
  console.log(req.body.email);
  console.log(req.body.upwd);
  //验证账户是否存在
  let sql = "select * from hotel_user where email=? and upwd=?";
  pool.query(sql, [email, upwd], (err, results) => {
    if (err) throw err;
    if (results.length) {
      res.send({ code: 0, message: "OK", usermaster: results[0] });
    } else {
      res.send({ code: 1, message: "账号或密码不正确" });
    }
  });
});
//王胜艺
app.get("/price", (req, res) => {
  let price = parseInt(req.query.price);
  pool.query(
    "select * from hotel_shop where price>?",
    [price],
    (err, results) => {
      if (err) throw err;
      res.send(results);
    }
  );
});
app.get("/sort", (req, res) => {
  pool.query("select * from hotel_shop", (err, results) => {
    if (err) throw err;
    res.send(results);
  });
});
